<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-04 19:25:50 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 19:25:50 --> Severity: Notice --> Undefined variable: page_css C:\danxampp\htdocs\demo\application\modules\admintemplate\views\head.php 25
ERROR - 2020-01-04 19:25:50 --> Severity: Notice --> Undefined variable: breadcrumbs C:\danxampp\htdocs\demo\application\modules\admintemplate\views\sidebars.php 98
ERROR - 2020-01-04 19:25:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\danxampp\htdocs\demo\application\modules\admintemplate\views\sidebars.php 98
ERROR - 2020-01-04 19:25:50 --> Severity: Notice --> Undefined variable: page_title C:\danxampp\htdocs\demo\application\modules\admintemplate\views\sidebars.php 102
ERROR - 2020-01-04 19:25:50 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 19:25:50 --> 404 Page Not Found: /index
ERROR - 2020-01-04 19:33:48 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 19:33:48 --> Query error: Duplicate entry '3449' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3449', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-04')
ERROR - 2020-01-04 19:33:48 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 19:33:48 --> Severity: Notice --> Undefined variable: page_css C:\danxampp\htdocs\demo\application\modules\admintemplate\views\head.php 25
ERROR - 2020-01-04 19:33:48 --> Severity: Notice --> Undefined variable: breadcrumbs C:\danxampp\htdocs\demo\application\modules\admintemplate\views\sidebars.php 98
ERROR - 2020-01-04 19:33:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\danxampp\htdocs\demo\application\modules\admintemplate\views\sidebars.php 98
ERROR - 2020-01-04 19:33:48 --> Severity: Notice --> Undefined variable: page_title C:\danxampp\htdocs\demo\application\modules\admintemplate\views\sidebars.php 102
ERROR - 2020-01-04 19:33:48 --> Severity: Notice --> Use of undefined constant errUpload - assumed 'errUpload' C:\danxampp\htdocs\demo\application\modules\importdb\views\importdb.php 51
ERROR - 2020-01-04 19:33:48 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 19:33:48 --> 404 Page Not Found: /index
ERROR - 2020-01-04 19:40:06 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 19:40:06 --> Severity: Notice --> Undefined variable: page_css C:\danxampp\htdocs\demo\application\modules\admintemplate\views\head.php 25
ERROR - 2020-01-04 19:40:06 --> Severity: Notice --> Undefined variable: breadcrumbs C:\danxampp\htdocs\demo\application\modules\admintemplate\views\sidebars.php 98
ERROR - 2020-01-04 19:40:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\danxampp\htdocs\demo\application\modules\admintemplate\views\sidebars.php 98
ERROR - 2020-01-04 19:40:06 --> Severity: Notice --> Undefined variable: page_title C:\danxampp\htdocs\demo\application\modules\admintemplate\views\sidebars.php 102
ERROR - 2020-01-04 19:40:06 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 19:40:06 --> 404 Page Not Found: /index
ERROR - 2020-01-04 19:40:11 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 19:40:11 --> Query error: Duplicate entry '3449' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3449', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-04')
ERROR - 2020-01-04 19:40:11 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 19:40:11 --> Severity: Notice --> Undefined variable: page_css C:\danxampp\htdocs\demo\application\modules\admintemplate\views\head.php 25
ERROR - 2020-01-04 19:40:11 --> Severity: Notice --> Undefined variable: breadcrumbs C:\danxampp\htdocs\demo\application\modules\admintemplate\views\sidebars.php 98
ERROR - 2020-01-04 19:40:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\danxampp\htdocs\demo\application\modules\admintemplate\views\sidebars.php 98
ERROR - 2020-01-04 19:40:11 --> Severity: Notice --> Undefined variable: page_title C:\danxampp\htdocs\demo\application\modules\admintemplate\views\sidebars.php 102
ERROR - 2020-01-04 19:40:11 --> Severity: Notice --> Use of undefined constant errUpload - assumed 'errUpload' C:\danxampp\htdocs\demo\application\modules\importdb\views\importdb.php 51
ERROR - 2020-01-04 19:40:12 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 19:40:12 --> 404 Page Not Found: /index
ERROR - 2020-01-04 19:41:06 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 19:41:06 --> Query error: Duplicate entry '3449' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3449', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-04')
ERROR - 2020-01-04 19:42:48 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 19:42:48 --> Query error: Duplicate entry '3449' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3449', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-04')
ERROR - 2020-01-04 19:42:50 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 19:42:50 --> Severity: Notice --> Undefined variable: page_css C:\danxampp\htdocs\demo\application\modules\admintemplate\views\head.php 25
ERROR - 2020-01-04 19:42:50 --> Severity: Notice --> Undefined variable: breadcrumbs C:\danxampp\htdocs\demo\application\modules\admintemplate\views\sidebars.php 98
ERROR - 2020-01-04 19:42:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\danxampp\htdocs\demo\application\modules\admintemplate\views\sidebars.php 98
ERROR - 2020-01-04 19:42:50 --> Severity: Notice --> Undefined variable: page_title C:\danxampp\htdocs\demo\application\modules\admintemplate\views\sidebars.php 102
ERROR - 2020-01-04 19:42:51 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 19:42:51 --> Severity: Notice --> Undefined variable: page_css C:\danxampp\htdocs\demo\application\modules\admintemplate\views\head.php 25
ERROR - 2020-01-04 19:42:51 --> Severity: Notice --> Undefined variable: breadcrumbs C:\danxampp\htdocs\demo\application\modules\admintemplate\views\sidebars.php 98
ERROR - 2020-01-04 19:42:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\danxampp\htdocs\demo\application\modules\admintemplate\views\sidebars.php 98
ERROR - 2020-01-04 19:42:51 --> Severity: Notice --> Undefined variable: page_title C:\danxampp\htdocs\demo\application\modules\admintemplate\views\sidebars.php 102
ERROR - 2020-01-04 19:42:51 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 19:42:51 --> 404 Page Not Found: /index
ERROR - 2020-01-04 19:42:55 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 19:42:55 --> Query error: Duplicate entry '3449' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3449', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-04')
ERROR - 2020-01-04 19:43:20 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 19:43:20 --> Query error: Duplicate entry '3449' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3449', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-04')
ERROR - 2020-01-04 19:43:21 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 19:43:21 --> Severity: Notice --> Undefined variable: page_css C:\danxampp\htdocs\demo\application\modules\admintemplate\views\head.php 25
ERROR - 2020-01-04 19:43:21 --> Severity: Notice --> Undefined variable: breadcrumbs C:\danxampp\htdocs\demo\application\modules\admintemplate\views\sidebars.php 98
ERROR - 2020-01-04 19:43:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\danxampp\htdocs\demo\application\modules\admintemplate\views\sidebars.php 98
ERROR - 2020-01-04 19:43:21 --> Severity: Notice --> Undefined variable: page_title C:\danxampp\htdocs\demo\application\modules\admintemplate\views\sidebars.php 102
ERROR - 2020-01-04 19:43:22 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 19:43:22 --> Severity: Notice --> Undefined variable: page_css C:\danxampp\htdocs\demo\application\modules\admintemplate\views\head.php 25
ERROR - 2020-01-04 19:43:22 --> Severity: Notice --> Undefined variable: breadcrumbs C:\danxampp\htdocs\demo\application\modules\admintemplate\views\sidebars.php 98
ERROR - 2020-01-04 19:43:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\danxampp\htdocs\demo\application\modules\admintemplate\views\sidebars.php 98
ERROR - 2020-01-04 19:43:22 --> Severity: Notice --> Undefined variable: page_title C:\danxampp\htdocs\demo\application\modules\admintemplate\views\sidebars.php 102
ERROR - 2020-01-04 19:43:23 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 19:43:23 --> 404 Page Not Found: /index
ERROR - 2020-01-04 19:46:41 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 19:46:41 --> Severity: Notice --> Undefined variable: page_css C:\danxampp\htdocs\demo\application\modules\admintemplate\views\head.php 25
ERROR - 2020-01-04 19:46:41 --> Severity: Notice --> Undefined variable: breadcrumbs C:\danxampp\htdocs\demo\application\modules\admintemplate\views\sidebars.php 98
ERROR - 2020-01-04 19:46:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\danxampp\htdocs\demo\application\modules\admintemplate\views\sidebars.php 98
ERROR - 2020-01-04 19:46:41 --> Severity: Notice --> Undefined variable: page_title C:\danxampp\htdocs\demo\application\modules\admintemplate\views\sidebars.php 102
ERROR - 2020-01-04 19:46:41 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 19:46:41 --> 404 Page Not Found: /index
ERROR - 2020-01-04 19:46:46 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 19:46:46 --> Query error: Duplicate entry '3449' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3449', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-04')
ERROR - 2020-01-04 19:46:46 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 128
ERROR - 2020-01-04 19:47:29 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 19:47:29 --> Query error: Duplicate entry '3449' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3449', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-04')
ERROR - 2020-01-04 19:47:57 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 19:47:57 --> Query error: Duplicate entry '3449' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3449', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-04')
ERROR - 2020-01-04 19:48:30 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 19:51:38 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 19:51:38 --> Severity: error --> Exception: syntax error, unexpected ''import_tvet'' (T_CONSTANT_ENCAPSED_STRING), expecting variable (T_VARIABLE) C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 98
ERROR - 2020-01-04 19:52:53 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 19:52:53 --> Severity: error --> Exception: syntax error, unexpected ''import_tvet'' (T_CONSTANT_ENCAPSED_STRING), expecting variable (T_VARIABLE) C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 98
ERROR - 2020-01-04 19:53:16 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 19:53:16 --> Severity: error --> Exception: syntax error, unexpected ''import_tvet'' (T_CONSTANT_ENCAPSED_STRING), expecting variable (T_VARIABLE) C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 98
ERROR - 2020-01-04 19:54:00 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 19:54:32 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 19:54:32 --> Severity: Notice --> Undefined variable: page_css C:\danxampp\htdocs\demo\application\modules\admintemplate\views\head.php 25
ERROR - 2020-01-04 19:54:32 --> Severity: Notice --> Undefined variable: breadcrumbs C:\danxampp\htdocs\demo\application\modules\admintemplate\views\sidebars.php 98
ERROR - 2020-01-04 19:54:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\danxampp\htdocs\demo\application\modules\admintemplate\views\sidebars.php 98
ERROR - 2020-01-04 19:54:32 --> Severity: Notice --> Undefined variable: page_title C:\danxampp\htdocs\demo\application\modules\admintemplate\views\sidebars.php 102
ERROR - 2020-01-04 19:54:33 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 19:54:33 --> Severity: Notice --> Undefined variable: page_css C:\danxampp\htdocs\demo\application\modules\admintemplate\views\head.php 25
ERROR - 2020-01-04 19:54:33 --> Severity: Notice --> Undefined variable: breadcrumbs C:\danxampp\htdocs\demo\application\modules\admintemplate\views\sidebars.php 98
ERROR - 2020-01-04 19:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\danxampp\htdocs\demo\application\modules\admintemplate\views\sidebars.php 98
ERROR - 2020-01-04 19:54:33 --> Severity: Notice --> Undefined variable: page_title C:\danxampp\htdocs\demo\application\modules\admintemplate\views\sidebars.php 102
ERROR - 2020-01-04 19:54:33 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 19:54:33 --> 404 Page Not Found: /index
ERROR - 2020-01-04 19:54:39 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 19:54:39 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:39 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:39 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:39 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:39 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:39 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:39 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:39 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:39 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:39 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:39 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:39 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:39 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:39 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:39 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:39 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:39 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:39 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:39 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:39 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:39 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:39 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:39 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:39 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:39 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:39 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:39 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:39 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:39 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:39 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:39 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:39 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:39 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:39 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:39 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:39 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:39 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:39 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:39 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:39 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:39 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:39 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:39 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:39 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:39 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:39 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:39 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:39 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:39 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:39 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:39 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:39 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:39 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:39 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:39 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:39 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:39 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:39 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:39 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:39 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:39 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:39 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:42 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:43 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:44 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:45 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:46 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:47 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:48 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:49 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:50 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:51 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:52 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:53 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:54 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:55 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:56 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:57 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:58 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:54:59 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:00 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:01 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:02 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:03 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:04 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:05 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:06 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:07 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:07 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:07 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:07 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:07 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:07 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:07 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:07 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:07 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:07 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:07 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:07 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:07 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:07 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:07 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:07 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:07 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:07 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:07 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:07 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:07 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:07 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:07 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:07 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:07 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:07 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:07 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:07 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:07 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:07 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:07 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:07 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:07 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:07 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:07 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:07 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:07 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:07 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:07 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:07 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:07 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:07 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:07 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:07 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:07 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:07 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:07 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:07 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:07 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:07 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:07 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:07 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:07 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:07 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:07 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:07 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:07 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:07 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:07 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:07 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:07 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:07 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:07 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:07 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:07 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:07 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:07 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:07 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:07 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:07 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:08 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:08 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:08 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:08 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:08 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:08 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:08 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:08 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:08 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:08 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:08 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:08 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:08 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:08 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:08 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:08 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:08 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:08 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:08 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:08 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:08 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:08 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:08 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:08 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:08 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:08 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:08 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:08 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:08 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:08 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:08 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:08 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:08 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:08 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:08 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:08 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:08 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:08 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:08 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:08 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:08 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:08 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:08 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:08 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:08 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:08 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:08 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:08 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:08 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:08 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:08 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:08 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:08 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:08 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:08 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:08 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:08 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:08 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:08 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:08 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:08 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:08 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:08 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:08 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:08 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:08 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:08 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:08 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:08 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:08 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:08 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:09 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:09 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:09 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:09 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:09 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:09 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:09 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:09 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:09 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:09 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:09 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:09 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:09 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:09 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:09 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:09 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:09 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:09 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:09 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:09 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:09 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:09 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:09 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:09 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:09 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:09 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:09 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:09 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:09 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:09 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:09 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:09 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:09 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:09 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:09 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:09 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:09 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:09 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:09 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:09 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:09 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:09 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:09 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:09 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:09 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:09 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:09 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:09 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:09 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:09 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:09 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:09 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:09 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:09 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:09 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:09 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:09 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:09 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:09 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:09 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:09 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:09 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:09 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:09 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:09 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:09 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:09 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:09 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:10 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:10 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:10 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:10 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:10 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:10 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:10 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:10 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:10 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:10 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:10 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:10 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:10 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:10 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:10 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:10 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:10 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:10 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:10 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:10 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:10 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:10 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:10 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:10 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:10 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:10 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:10 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:10 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:10 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:10 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:10 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:10 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:10 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:10 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:10 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:10 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:10 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:10 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:10 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:10 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:10 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:10 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:10 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:10 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:10 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:10 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:10 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:10 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:10 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:10 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:10 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:10 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:10 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:10 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:10 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:10 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:10 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:10 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:10 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:10 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:10 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:10 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:10 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:10 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:10 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:10 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:10 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:10 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:10 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:11 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:11 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:11 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:11 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:11 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:11 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:11 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:11 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:11 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:11 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:11 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:11 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:11 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:11 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:11 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:11 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:11 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:11 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:11 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:11 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:11 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:11 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:11 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:11 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:11 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:11 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:11 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:11 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:11 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:11 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:11 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:11 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:11 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:11 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:11 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:11 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:11 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:11 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:11 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:11 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:11 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:11 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:11 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:11 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:11 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:11 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:11 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:11 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:11 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:11 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:11 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:11 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:11 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:11 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:11 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:11 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:11 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:11 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:11 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:11 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:11 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:11 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:11 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:11 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:12 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:12 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:12 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:12 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:12 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:12 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:12 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:12 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:12 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:12 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:12 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:12 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:12 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:12 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:12 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:12 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:12 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:12 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:12 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:12 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:12 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:12 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:12 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:12 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:12 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:12 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:12 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:12 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:12 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:12 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:12 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:12 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:12 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:12 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:12 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:12 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:12 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:12 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:12 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:12 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:12 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:12 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:12 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:12 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:12 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:12 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:12 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:12 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:12 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:12 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:12 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:12 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:12 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:12 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:12 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:12 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:12 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:12 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:12 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:12 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:12 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:12 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:12 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:12 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:12 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:12 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:12 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:12 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:13 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:13 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:13 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:13 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:13 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:13 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:13 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:13 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:13 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:13 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:13 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:13 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:13 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:13 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:13 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:13 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:13 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:13 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:13 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:13 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:13 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:13 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:13 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:13 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:13 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:13 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:13 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:13 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:13 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:13 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:13 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:13 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:13 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:13 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:13 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:13 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:13 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:13 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:13 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:13 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:13 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:13 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:13 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:13 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:13 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:13 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:13 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:13 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:13 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:13 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:13 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:13 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:13 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:13 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:13 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:13 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:13 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:13 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:13 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:13 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:13 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:13 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:13 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:13 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:13 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:13 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:14 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:14 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:14 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:14 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:14 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:14 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:14 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:14 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:14 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:14 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:14 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:14 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:14 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:14 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:14 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:14 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:14 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:14 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:14 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:14 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:14 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:14 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:14 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:14 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:14 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:14 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:14 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:14 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:14 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:14 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:14 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:14 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:14 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:14 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:14 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:14 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:14 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:14 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:14 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:14 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:14 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:14 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:14 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:14 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:14 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:14 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:14 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:14 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:14 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:14 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:14 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:14 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:14 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:14 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:14 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:14 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:14 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:14 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:14 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:14 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:14 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:14 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:14 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:14 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:14 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:15 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:15 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:15 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:15 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:15 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:15 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:15 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:15 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:15 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:15 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:15 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:15 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:15 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:15 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:15 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:15 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:15 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:15 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:15 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:15 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:15 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:15 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:15 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:15 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:15 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:15 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:15 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:15 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:15 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:15 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:15 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:15 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:15 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:15 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:15 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:15 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:15 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:15 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:15 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:15 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:15 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:15 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:15 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:15 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:15 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:15 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:15 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:15 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:15 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:15 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:15 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:15 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:15 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:15 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:15 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:15 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:15 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:15 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:15 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:15 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:15 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:15 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:15 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:15 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:16 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:16 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:16 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:16 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:16 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:16 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:16 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:16 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:16 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:16 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:16 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:16 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:16 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:16 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:16 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:16 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:16 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:16 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:16 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:16 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:16 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:16 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:16 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:16 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:16 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:16 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:16 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:16 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:16 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:16 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:16 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:16 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:16 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:16 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:16 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:16 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:16 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:16 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:16 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:16 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:16 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:16 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:16 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:16 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:16 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:16 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:16 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:16 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:16 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:16 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:16 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:16 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:16 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:16 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:16 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:16 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:16 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:16 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:16 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:16 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:16 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:16 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:16 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:17 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:17 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:17 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:17 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:17 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:17 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:17 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:17 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:17 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:17 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:17 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:17 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:17 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:17 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:17 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:17 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:17 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:17 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:17 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:17 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:17 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:17 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:17 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:17 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:17 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:17 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:17 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:17 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:17 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:17 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:17 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:17 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:17 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:17 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:17 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:17 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:17 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:17 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:17 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:17 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:17 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:17 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:17 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:17 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:17 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:17 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:17 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:17 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:17 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:17 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:17 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:17 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:17 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:17 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:17 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:17 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:17 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:17 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:17 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:17 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:17 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:17 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:17 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:18 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:18 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:18 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:18 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:18 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:18 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:18 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:18 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:18 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:18 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:18 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:18 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:18 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:18 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:18 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:18 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:18 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:18 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:18 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:18 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:18 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:18 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:18 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:18 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:18 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:18 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:18 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:18 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:18 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:18 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:18 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:18 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:18 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:18 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:18 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:18 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:18 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:18 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:18 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:18 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:18 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:18 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:18 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:18 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:18 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:18 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:18 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:18 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:18 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:18 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:18 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:18 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:18 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:18 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:18 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:18 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:18 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:18 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:18 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:18 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:18 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:18 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:19 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:19 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:19 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:19 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:19 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:19 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:19 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:19 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:19 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:19 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:19 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:19 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:19 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:19 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:19 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:19 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:19 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:19 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:19 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:19 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:19 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:19 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:19 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:19 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:19 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:19 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:19 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:19 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:19 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:19 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:19 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:19 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:19 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:19 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:19 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:19 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:19 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:19 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:19 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:19 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:19 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:19 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:19 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:19 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:19 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:19 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:19 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:19 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:19 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:19 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:19 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:19 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:19 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:19 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:19 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:19 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:19 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:19 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:19 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:19 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:19 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:20 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:20 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:20 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:20 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:20 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:20 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:20 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:20 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:20 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:20 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:20 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:20 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:20 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:20 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:20 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:20 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:20 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:20 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:20 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:20 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:20 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:20 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:20 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:20 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:20 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:20 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:20 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:20 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:20 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:20 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:20 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:20 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:20 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:20 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:20 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:20 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:20 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:20 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:20 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:20 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:20 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:20 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:20 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:20 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:20 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:20 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:20 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:20 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:20 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:20 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:20 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:20 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:20 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:20 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:20 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:20 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:20 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:20 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:20 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:20 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:20 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:21 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:21 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:21 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:21 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:21 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:21 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:21 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:21 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:21 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:21 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:21 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:21 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:21 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:21 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:21 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:21 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:21 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:21 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:21 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:21 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:21 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:21 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:21 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:21 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:21 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:21 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:21 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:21 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:21 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:21 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:21 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:21 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:21 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:21 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:21 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:21 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:21 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:21 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:21 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:21 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:21 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:21 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:21 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:21 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:21 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:21 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:21 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:21 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:21 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:21 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:21 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:21 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:21 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:21 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:21 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:21 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:21 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:21 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:21 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:21 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:21 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:22 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:22 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:22 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:22 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:22 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:22 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:22 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:22 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:22 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:22 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:22 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:22 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:22 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:22 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:22 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:22 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:22 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:22 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:22 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:22 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:22 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:22 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:22 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:22 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:22 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:22 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:22 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:22 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:22 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:22 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:22 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:22 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:22 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:22 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:22 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:22 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:22 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:22 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:22 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:22 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:22 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:22 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:22 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:22 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:22 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:22 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:22 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:22 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:22 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:22 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:22 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:22 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:22 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:22 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:22 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:22 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:22 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:22 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:22 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:22 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:23 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:23 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:23 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:23 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:23 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:23 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:23 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:23 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:23 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:23 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:23 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:23 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:23 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:23 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:23 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:23 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:23 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:23 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:23 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:23 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:23 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:23 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:23 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:23 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:23 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:23 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:23 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:23 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:23 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:23 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:23 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:23 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:23 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:23 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:23 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:23 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:23 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:23 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:23 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:23 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:23 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:23 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:23 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:23 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:23 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:23 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:23 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:23 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:23 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:23 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:23 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:23 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:23 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:23 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:23 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:23 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:23 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:23 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:23 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:24 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:24 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:24 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:24 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:24 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:24 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:24 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:24 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:24 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:24 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:24 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:24 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:24 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:24 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:24 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:24 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:24 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:24 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:24 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:24 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:24 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:24 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:24 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:24 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:24 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:24 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:24 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:24 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:24 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:24 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:24 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:24 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:24 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:24 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:24 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:24 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:24 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:24 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:24 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:24 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:24 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:24 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:24 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:24 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:24 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:24 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:24 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:24 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:24 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:24 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:24 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:24 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:24 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:24 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:24 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:24 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:24 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:24 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:24 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:25 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:25 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:25 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:25 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:25 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:25 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:25 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:25 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:25 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:25 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:25 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:25 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:25 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:25 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:25 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:25 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:25 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:25 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:25 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:25 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:25 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:25 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:25 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:25 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:25 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:25 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:25 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:25 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:25 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:25 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:25 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:25 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:25 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:25 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:25 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:25 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:25 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:25 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:25 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:25 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:25 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:25 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:25 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:25 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:25 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:25 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:25 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:25 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:25 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:25 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:25 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:25 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:25 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:25 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:25 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:25 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:25 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:25 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:26 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:26 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:26 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:26 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:26 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:26 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:26 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:26 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:26 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:26 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:26 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:26 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:26 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:26 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:26 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:26 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:26 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:26 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:26 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:26 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:26 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:26 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:26 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:26 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:26 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:26 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:26 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:26 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:26 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:26 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:26 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:26 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:26 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:26 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:26 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:26 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:26 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:26 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:26 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:26 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:26 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:26 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:26 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:26 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:26 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:26 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:26 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:26 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:26 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:26 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:26 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:26 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:26 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:26 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:26 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:26 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:26 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:26 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:27 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:27 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:27 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:27 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:27 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:27 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:27 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:27 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:27 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:27 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:27 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:27 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:27 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:27 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:27 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:27 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:27 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:27 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:27 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:27 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:27 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:27 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:27 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:27 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:27 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:27 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:27 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:27 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:27 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:27 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:27 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:27 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:27 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:27 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:27 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:27 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:27 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:27 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:27 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:27 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:27 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:27 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:27 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:27 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:27 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:27 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:27 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:27 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:27 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:27 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:27 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:27 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:27 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:27 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:27 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:27 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:27 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:27 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:28 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:28 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:28 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:28 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:28 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:28 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:28 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:28 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:28 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:28 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:28 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:28 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:28 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:28 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:28 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:28 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:28 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:28 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:28 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:28 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:28 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:28 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:28 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:28 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:28 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:28 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:28 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:28 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:28 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:28 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:28 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:28 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:28 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:28 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:28 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:28 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:28 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:28 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:28 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:28 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:28 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:28 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:28 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:28 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:28 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:28 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:28 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:28 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:28 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:28 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:28 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:28 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:28 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:28 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:28 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:28 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:28 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:28 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:29 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:29 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:29 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:29 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:29 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:29 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:29 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:29 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:29 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:29 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:29 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:29 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:29 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:29 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:29 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:29 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:29 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:29 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:29 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:29 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:29 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:29 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:29 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:29 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:29 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:29 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:29 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:29 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:29 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:29 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:29 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:29 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:29 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:29 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:29 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:29 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:29 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:29 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:29 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:29 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:29 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:29 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:29 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:29 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:29 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:29 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:29 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:29 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:29 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:29 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:29 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:29 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:29 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:29 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:29 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:29 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:29 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:29 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:30 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:30 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:30 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:30 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:30 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:30 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:30 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:30 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:30 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:30 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:30 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:30 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:30 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:30 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:30 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:30 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:30 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:30 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:30 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:30 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:30 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:30 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:30 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:30 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:30 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:30 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:30 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:30 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:30 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:30 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:30 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:30 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:30 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:30 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:30 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:30 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:30 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:30 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:30 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:30 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:30 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:30 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:30 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:30 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:30 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:30 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:30 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:30 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:30 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:30 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:30 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:30 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:30 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:30 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:30 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:30 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:30 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:30 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:30 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:31 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:31 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:31 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:31 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:31 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:31 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:31 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:31 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:31 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:31 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:31 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:31 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:31 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:31 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:31 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:31 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:31 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:31 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:31 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:31 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:31 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:31 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:31 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:31 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:31 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:31 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:31 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:31 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:31 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:31 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:31 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:31 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:31 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:31 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:31 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:31 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:31 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:31 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:31 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:31 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:31 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:31 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:31 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:31 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:31 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:31 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:31 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:31 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:31 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:31 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:31 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:31 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:31 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:31 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:31 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:31 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:32 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:32 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:32 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:32 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:32 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:32 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:32 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:32 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:32 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:32 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:32 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:32 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:32 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:32 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:32 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:32 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:32 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:32 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:32 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:32 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:32 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:32 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:32 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:32 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:32 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:32 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:32 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:32 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:32 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:32 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:32 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:32 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:32 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:32 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:32 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:32 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:32 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:32 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:32 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:32 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:32 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:32 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:32 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:32 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:32 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:32 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:32 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:32 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:32 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:32 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:32 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:32 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:32 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:32 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:32 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:32 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:32 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:33 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:33 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:33 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:33 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:33 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:33 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:33 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:33 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:33 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:33 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:33 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:33 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:33 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:33 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:33 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:33 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:33 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:33 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:33 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:33 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:33 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:33 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:33 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:33 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:33 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:33 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:33 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:33 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:33 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:33 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:33 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:33 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:33 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:33 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:33 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:33 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:33 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:33 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:33 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:33 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:33 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:33 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:33 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:33 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:33 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:33 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:33 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:33 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:33 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:33 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:33 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:33 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:33 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:33 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:33 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:34 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:34 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:34 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:34 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:34 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:34 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:34 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:34 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:34 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:34 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:34 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:34 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:34 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:34 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:34 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:34 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:34 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:34 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:34 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:34 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:34 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:34 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:34 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:34 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:34 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:34 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:34 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:34 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:34 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:34 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:34 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:34 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:34 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:34 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:34 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:34 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:34 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:34 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:34 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:34 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:34 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:34 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:34 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:34 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:34 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:34 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:34 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:34 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:34 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:34 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:34 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:34 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:34 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:35 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:35 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:35 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:35 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:35 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:35 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:35 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:35 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:35 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:35 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:35 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:35 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:35 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:35 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:35 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:35 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:35 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:35 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:35 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:35 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:35 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:35 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:35 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:35 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:35 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:35 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:35 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:35 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:35 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:35 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:35 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:35 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:35 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:35 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:35 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:35 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:35 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:35 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:35 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:35 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:35 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:35 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:35 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:35 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:35 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:35 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:35 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:35 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:35 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:35 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:35 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:35 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:35 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:35 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:35 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:36 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:36 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:36 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:36 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:36 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:36 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:36 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:36 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:36 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:36 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:36 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:36 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:36 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:36 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:36 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:36 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:36 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:36 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:36 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:36 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:36 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:36 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:36 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:36 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:36 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:36 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:36 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:36 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:36 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:36 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:36 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:36 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:36 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:36 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:36 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:36 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:36 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:36 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:36 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:36 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:36 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:36 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:36 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:36 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:36 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:36 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:36 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:36 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:36 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:36 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:36 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:36 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:36 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:36 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:37 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:37 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:37 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:37 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:37 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:37 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:37 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:37 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:37 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:37 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:37 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:37 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:37 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:37 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:37 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:37 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:37 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:37 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:37 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:37 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:37 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:37 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:37 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:37 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:37 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:37 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:37 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:37 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:37 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:37 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:37 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:37 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:37 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:37 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:37 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:37 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:37 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:37 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:37 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:37 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:37 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:37 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:37 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:37 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:37 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:37 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:37 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:37 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:37 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:37 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:37 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:37 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:37 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:37 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:37 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:38 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:38 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:38 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:38 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:38 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:38 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:38 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:38 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:38 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:38 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:38 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:38 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:38 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:38 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:38 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:38 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:38 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:38 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:38 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:38 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:38 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:38 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:38 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:38 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:38 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:38 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:38 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:38 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:38 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:38 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:38 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:38 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:38 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:38 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:38 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:38 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:38 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:38 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:38 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:38 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:38 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:38 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:38 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:38 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:38 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:38 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:38 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:38 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:38 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:39 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:39 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:39 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:39 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:39 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:39 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:39 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:39 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:39 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:39 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:39 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:39 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:39 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:39 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:39 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:39 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:39 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:39 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:39 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:39 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:39 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:39 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:39 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:39 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:39 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:39 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:39 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:39 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:39 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:39 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:39 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:39 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:39 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:39 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:39 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:39 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:39 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:39 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:39 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:39 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:39 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:39 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:39 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:39 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:39 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:39 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:39 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:39 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:39 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:39 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:39 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:39 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:39 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:40 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:40 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:41 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:41 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:42 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:42 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:42 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:42 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 109
ERROR - 2020-01-04 19:55:42 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 19:55:42 --> Severity: Notice --> Undefined variable: page_css C:\danxampp\htdocs\demo\application\modules\admintemplate\views\head.php 25
ERROR - 2020-01-04 19:55:42 --> Severity: Notice --> Undefined variable: breadcrumbs C:\danxampp\htdocs\demo\application\modules\admintemplate\views\sidebars.php 98
ERROR - 2020-01-04 19:55:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\danxampp\htdocs\demo\application\modules\admintemplate\views\sidebars.php 98
ERROR - 2020-01-04 19:55:42 --> Severity: Notice --> Undefined variable: page_title C:\danxampp\htdocs\demo\application\modules\admintemplate\views\sidebars.php 102
ERROR - 2020-01-04 19:55:44 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 19:55:44 --> Severity: Notice --> Undefined variable: page_css C:\danxampp\htdocs\demo\application\modules\admintemplate\views\head.php 25
ERROR - 2020-01-04 19:55:44 --> Severity: Notice --> Undefined variable: breadcrumbs C:\danxampp\htdocs\demo\application\modules\admintemplate\views\sidebars.php 98
ERROR - 2020-01-04 19:55:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\danxampp\htdocs\demo\application\modules\admintemplate\views\sidebars.php 98
ERROR - 2020-01-04 19:55:44 --> Severity: Notice --> Undefined variable: page_title C:\danxampp\htdocs\demo\application\modules\admintemplate\views\sidebars.php 102
ERROR - 2020-01-04 19:55:44 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 19:55:44 --> 404 Page Not Found: /index
ERROR - 2020-01-04 19:55:49 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 19:55:49 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 100
ERROR - 2020-01-04 19:55:49 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 100
ERROR - 2020-01-04 19:55:49 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 19:55:49 --> Severity: Notice --> Undefined variable: page_css C:\danxampp\htdocs\demo\application\modules\admintemplate\views\head.php 25
ERROR - 2020-01-04 19:55:49 --> Severity: Notice --> Undefined variable: breadcrumbs C:\danxampp\htdocs\demo\application\modules\admintemplate\views\sidebars.php 98
ERROR - 2020-01-04 19:55:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\danxampp\htdocs\demo\application\modules\admintemplate\views\sidebars.php 98
ERROR - 2020-01-04 19:55:49 --> Severity: Notice --> Undefined variable: page_title C:\danxampp\htdocs\demo\application\modules\admintemplate\views\sidebars.php 102
ERROR - 2020-01-04 19:55:49 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 19:55:49 --> 404 Page Not Found: /index
ERROR - 2020-01-04 19:55:59 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 19:55:59 --> Severity: Notice --> Undefined variable: file C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 100
ERROR - 2020-01-04 19:55:59 --> Severity: Warning --> fgetcsv() expects parameter 1 to be resource, null given C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 100
ERROR - 2020-01-04 19:55:59 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 19:55:59 --> Severity: Notice --> Undefined variable: page_css C:\danxampp\htdocs\demo\application\modules\admintemplate\views\head.php 25
ERROR - 2020-01-04 19:55:59 --> Severity: Notice --> Undefined variable: breadcrumbs C:\danxampp\htdocs\demo\application\modules\admintemplate\views\sidebars.php 98
ERROR - 2020-01-04 19:55:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\danxampp\htdocs\demo\application\modules\admintemplate\views\sidebars.php 98
ERROR - 2020-01-04 19:55:59 --> Severity: Notice --> Undefined variable: page_title C:\danxampp\htdocs\demo\application\modules\admintemplate\views\sidebars.php 102
ERROR - 2020-01-04 19:55:59 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 19:55:59 --> 404 Page Not Found: /index
ERROR - 2020-01-04 19:56:41 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 19:56:41 --> Severity: Notice --> Undefined variable: page_css C:\danxampp\htdocs\demo\application\modules\admintemplate\views\head.php 25
ERROR - 2020-01-04 19:56:41 --> Severity: Notice --> Undefined variable: breadcrumbs C:\danxampp\htdocs\demo\application\modules\admintemplate\views\sidebars.php 98
ERROR - 2020-01-04 19:56:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\danxampp\htdocs\demo\application\modules\admintemplate\views\sidebars.php 98
ERROR - 2020-01-04 19:56:41 --> Severity: Notice --> Undefined variable: page_title C:\danxampp\htdocs\demo\application\modules\admintemplate\views\sidebars.php 102
ERROR - 2020-01-04 19:56:41 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 19:56:41 --> 404 Page Not Found: /index
ERROR - 2020-01-04 19:56:45 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 19:56:45 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 19:56:45 --> Severity: Notice --> Undefined variable: page_css C:\danxampp\htdocs\demo\application\modules\admintemplate\views\head.php 25
ERROR - 2020-01-04 19:56:45 --> Severity: Notice --> Undefined variable: breadcrumbs C:\danxampp\htdocs\demo\application\modules\admintemplate\views\sidebars.php 98
ERROR - 2020-01-04 19:56:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\danxampp\htdocs\demo\application\modules\admintemplate\views\sidebars.php 98
ERROR - 2020-01-04 19:56:45 --> Severity: Notice --> Undefined variable: page_title C:\danxampp\htdocs\demo\application\modules\admintemplate\views\sidebars.php 102
ERROR - 2020-01-04 19:56:45 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 19:56:45 --> 404 Page Not Found: /index
ERROR - 2020-01-04 19:58:02 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 19:58:02 --> Severity: Notice --> Undefined variable: page_css C:\danxampp\htdocs\demo\application\modules\admintemplate\views\head.php 25
ERROR - 2020-01-04 19:58:02 --> Severity: Notice --> Undefined variable: breadcrumbs C:\danxampp\htdocs\demo\application\modules\admintemplate\views\sidebars.php 98
ERROR - 2020-01-04 19:58:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\danxampp\htdocs\demo\application\modules\admintemplate\views\sidebars.php 98
ERROR - 2020-01-04 19:58:02 --> Severity: Notice --> Undefined variable: page_title C:\danxampp\htdocs\demo\application\modules\admintemplate\views\sidebars.php 102
ERROR - 2020-01-04 19:58:02 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 19:58:02 --> 404 Page Not Found: /index
ERROR - 2020-01-04 19:58:07 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 19:58:07 --> Query error: Duplicate entry '3449' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3449', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-04')
ERROR - 2020-01-04 19:58:07 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 19:58:07 --> Severity: Notice --> Undefined variable: page_css C:\danxampp\htdocs\demo\application\modules\admintemplate\views\head.php 25
ERROR - 2020-01-04 19:58:07 --> Severity: Notice --> Undefined variable: breadcrumbs C:\danxampp\htdocs\demo\application\modules\admintemplate\views\sidebars.php 98
ERROR - 2020-01-04 19:58:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\danxampp\htdocs\demo\application\modules\admintemplate\views\sidebars.php 98
ERROR - 2020-01-04 19:58:07 --> Severity: Notice --> Undefined variable: page_title C:\danxampp\htdocs\demo\application\modules\admintemplate\views\sidebars.php 102
ERROR - 2020-01-04 19:58:07 --> Severity: Notice --> Use of undefined constant errUpload - assumed 'errUpload' C:\danxampp\htdocs\demo\application\modules\importdb\views\importdb.php 51
ERROR - 2020-01-04 19:58:08 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 19:58:08 --> 404 Page Not Found: /index
ERROR - 2020-01-04 19:58:49 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 19:58:49 --> Severity: Notice --> Undefined variable: page_css C:\danxampp\htdocs\demo\application\modules\admintemplate\views\head.php 25
ERROR - 2020-01-04 19:58:49 --> Severity: Notice --> Undefined variable: breadcrumbs C:\danxampp\htdocs\demo\application\modules\admintemplate\views\sidebars.php 98
ERROR - 2020-01-04 19:58:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\danxampp\htdocs\demo\application\modules\admintemplate\views\sidebars.php 98
ERROR - 2020-01-04 19:58:49 --> Severity: Notice --> Undefined variable: page_title C:\danxampp\htdocs\demo\application\modules\admintemplate\views\sidebars.php 102
ERROR - 2020-01-04 19:58:49 --> Severity: Compile Error --> Cannot use isset() on the result of an expression (you can use "null !== expression" instead) C:\danxampp\htdocs\demo\application\modules\importdb\views\importdb.php 45
ERROR - 2020-01-04 19:59:14 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 19:59:14 --> Severity: Notice --> Undefined variable: page_css C:\danxampp\htdocs\demo\application\modules\admintemplate\views\head.php 25
ERROR - 2020-01-04 19:59:14 --> Severity: Notice --> Undefined variable: breadcrumbs C:\danxampp\htdocs\demo\application\modules\admintemplate\views\sidebars.php 98
ERROR - 2020-01-04 19:59:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\danxampp\htdocs\demo\application\modules\admintemplate\views\sidebars.php 98
ERROR - 2020-01-04 19:59:14 --> Severity: Notice --> Undefined variable: page_title C:\danxampp\htdocs\demo\application\modules\admintemplate\views\sidebars.php 102
ERROR - 2020-01-04 19:59:14 --> Severity: Compile Error --> Cannot use isset() on the result of an expression (you can use "null !== expression" instead) C:\danxampp\htdocs\demo\application\modules\importdb\views\importdb.php 45
ERROR - 2020-01-04 19:59:24 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 19:59:24 --> Severity: Notice --> Undefined variable: page_css C:\danxampp\htdocs\demo\application\modules\admintemplate\views\head.php 25
ERROR - 2020-01-04 19:59:24 --> Severity: Notice --> Undefined variable: breadcrumbs C:\danxampp\htdocs\demo\application\modules\admintemplate\views\sidebars.php 98
ERROR - 2020-01-04 19:59:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\danxampp\htdocs\demo\application\modules\admintemplate\views\sidebars.php 98
ERROR - 2020-01-04 19:59:24 --> Severity: Notice --> Undefined variable: page_title C:\danxampp\htdocs\demo\application\modules\admintemplate\views\sidebars.php 102
ERROR - 2020-01-04 19:59:24 --> Severity: Compile Error --> Cannot use isset() on the result of an expression (you can use "null !== expression" instead) C:\danxampp\htdocs\demo\application\modules\importdb\views\importdb.php 45
ERROR - 2020-01-04 19:59:32 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 19:59:32 --> Severity: Notice --> Undefined variable: page_css C:\danxampp\htdocs\demo\application\modules\admintemplate\views\head.php 25
ERROR - 2020-01-04 19:59:32 --> Severity: Notice --> Undefined variable: breadcrumbs C:\danxampp\htdocs\demo\application\modules\admintemplate\views\sidebars.php 98
ERROR - 2020-01-04 19:59:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\danxampp\htdocs\demo\application\modules\admintemplate\views\sidebars.php 98
ERROR - 2020-01-04 19:59:32 --> Severity: Notice --> Undefined variable: page_title C:\danxampp\htdocs\demo\application\modules\admintemplate\views\sidebars.php 102
ERROR - 2020-01-04 19:59:32 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 19:59:32 --> 404 Page Not Found: /index
ERROR - 2020-01-04 19:59:58 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 19:59:58 --> Severity: Notice --> Undefined variable: page_css C:\danxampp\htdocs\demo\application\modules\admintemplate\views\head.php 25
ERROR - 2020-01-04 19:59:58 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 19:59:58 --> 404 Page Not Found: /index
ERROR - 2020-01-04 20:00:03 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:00:03 --> Severity: Notice --> Undefined variable: page_css C:\danxampp\htdocs\demo\application\modules\admintemplate\views\head.php 25
ERROR - 2020-01-04 20:00:33 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:00:34 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:00:34 --> 404 Page Not Found: /index
ERROR - 2020-01-04 20:00:41 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:00:41 --> Query error: Duplicate entry '3449' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3449', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-04')
ERROR - 2020-01-04 20:00:41 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:00:41 --> Severity: Notice --> Use of undefined constant errUpload - assumed 'errUpload' C:\danxampp\htdocs\demo\application\modules\importdb\views\importdb.php 51
ERROR - 2020-01-04 20:00:41 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:00:41 --> 404 Page Not Found: /index
ERROR - 2020-01-04 20:01:13 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:01:14 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:01:14 --> 404 Page Not Found: /index
ERROR - 2020-01-04 20:01:26 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:01:26 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:01:26 --> 404 Page Not Found: /index
ERROR - 2020-01-04 20:01:30 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:01:31 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 167
ERROR - 2020-01-04 20:01:31 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:01:31 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:01:31 --> 404 Page Not Found: /index
ERROR - 2020-01-04 20:02:44 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:02:44 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:02:44 --> 404 Page Not Found: /index
ERROR - 2020-01-04 20:02:50 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:02:50 --> Query error: Duplicate entry '3449' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3449', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-04')
ERROR - 2020-01-04 20:03:42 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:03:43 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:03:44 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:03:44 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:03:44 --> 404 Page Not Found: /index
ERROR - 2020-01-04 20:03:48 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:03:48 --> Query error: Duplicate entry '3449' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3449', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-04')
ERROR - 2020-01-04 20:06:16 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:06:16 --> Severity: error --> Exception: syntax error, unexpected 'catch' (T_CATCH) C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 151
ERROR - 2020-01-04 20:06:17 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:06:17 --> Severity: error --> Exception: syntax error, unexpected 'catch' (T_CATCH) C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 151
ERROR - 2020-01-04 20:06:59 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:06:59 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:06:59 --> 404 Page Not Found: /index
ERROR - 2020-01-04 20:07:05 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:07:05 --> Query error: Duplicate entry '3449' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3449', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-04')
ERROR - 2020-01-04 20:07:05 --> Query error: Duplicate entry '3449' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3449', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-04')
ERROR - 2020-01-04 20:07:05 --> Query error: Duplicate entry '3449' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3449', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-04')
ERROR - 2020-01-04 20:07:05 --> Query error: Duplicate entry '3449' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3449', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-04')
ERROR - 2020-01-04 20:07:19 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:07:24 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:07:24 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:07:24 --> 404 Page Not Found: /index
ERROR - 2020-01-04 20:07:28 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:07:29 --> Query error: Duplicate entry '3449' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3449', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-04')
ERROR - 2020-01-04 20:07:29 --> Query error: Duplicate entry '3449' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3449', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-04')
ERROR - 2020-01-04 20:07:29 --> Query error: Duplicate entry '3449' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3449', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-04')
ERROR - 2020-01-04 20:07:29 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:07:29 --> Severity: Notice --> Use of undefined constant errUpload - assumed 'errUpload' C:\danxampp\htdocs\demo\application\modules\importdb\views\importdb.php 51
ERROR - 2020-01-04 20:07:29 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:07:29 --> 404 Page Not Found: /index
ERROR - 2020-01-04 20:08:29 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:08:29 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:08:30 --> 404 Page Not Found: /index
ERROR - 2020-01-04 20:08:35 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:08:35 --> Query error: Duplicate entry '3449' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3449', '3449', '3449', '3449', 1, '2020-01-04')
ERROR - 2020-01-04 20:08:35 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('Addis Ababa', 'Addis Ababa', 'Addis Ababa', 'Addis Ababa', 1, '2020-01-04')
ERROR - 2020-01-04 20:08:35 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('Private', 'Private', 'Private', 'Private', 1, '2020-01-04')
ERROR - 2020-01-04 20:08:35 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:08:35 --> Severity: Notice --> Use of undefined constant errUpload - assumed 'errUpload' C:\danxampp\htdocs\demo\application\modules\importdb\views\importdb.php 51
ERROR - 2020-01-04 20:08:35 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:08:35 --> 404 Page Not Found: /index
ERROR - 2020-01-04 20:09:36 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:09:36 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:09:36 --> 404 Page Not Found: /index
ERROR - 2020-01-04 20:09:40 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:09:40 --> Query error: Duplicate entry '3449' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3449', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-04')
ERROR - 2020-01-04 20:09:40 --> Query error: Duplicate entry '3449' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3449', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-04')
ERROR - 2020-01-04 20:09:41 --> Query error: Duplicate entry '3449' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3449', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-04')
ERROR - 2020-01-04 20:09:41 --> Query error: Duplicate entry '3449' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3449', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-04')
ERROR - 2020-01-04 20:11:42 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:11:43 --> Severity: error --> Exception: syntax error, unexpected ';' C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 128
ERROR - 2020-01-04 20:11:45 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:11:45 --> Severity: error --> Exception: syntax error, unexpected ';' C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 128
ERROR - 2020-01-04 20:12:11 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:12:11 --> Severity: error --> Exception: syntax error, unexpected ';' C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 128
ERROR - 2020-01-04 20:12:27 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:12:29 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:12:30 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:12:30 --> 404 Page Not Found: /index
ERROR - 2020-01-04 20:12:34 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:12:34 --> Query error: Duplicate entry '3449' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3449', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-04')
ERROR - 2020-01-04 20:13:40 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:13:41 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:13:41 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:13:41 --> 404 Page Not Found: /index
ERROR - 2020-01-04 20:13:45 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:17:19 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:17:20 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:17:21 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:17:21 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:17:21 --> 404 Page Not Found: /index
ERROR - 2020-01-04 20:17:26 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:17:26 --> Query error: Duplicate entry '3449' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`postdate`, `region`, `status`, `tvet_id`, `tvet_name`, `tvet_type`) VALUES ('2020-01-04','Addis Ababa',1,'3449','BBCY TVET','Private')
ERROR - 2020-01-04 20:17:41 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:17:56 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:18:12 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:18:58 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:20:25 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:21:03 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:21:05 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:21:57 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:22:01 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:22:23 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:22:23 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:22:23 --> 404 Page Not Found: /index
ERROR - 2020-01-04 20:22:27 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:22:27 --> Query error: Duplicate entry '3449' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`postdate`, `region`, `status`, `tvet_id`, `tvet_name`, `tvet_type`) VALUES ('2020-01-04','Addis Ababa',1,'3449','BBCY TVET','Private')
ERROR - 2020-01-04 20:22:40 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:23:58 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:23:59 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:24:02 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:24:02 --> Query error: Duplicate entry '3449' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`postdate`, `region`, `status`, `tvet_id`, `tvet_name`, `tvet_type`) VALUES ('2020-01-04','Addis Ababa',1,'3449','BBCY TVET','Private')
ERROR - 2020-01-04 20:24:18 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:24:18 --> Query error: Duplicate entry '3449' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`postdate`, `region`, `status`, `tvet_id`, `tvet_name`, `tvet_type`) VALUES ('2020-01-04','Addis Ababa',1,'3449','BBCY TVET','Private')
ERROR - 2020-01-04 20:24:44 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:24:57 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:24:57 --> Query error: Duplicate entry '3449' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`postdate`, `region`, `status`, `tvet_id`, `tvet_name`, `tvet_type`) VALUES ('2020-01-04','Addis Ababa',1,'3449','BBCY TVET','Private')
ERROR - 2020-01-04 20:26:45 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:26:45 --> Query error: Duplicate entry '3449' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3449', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-04')
ERROR - 2020-01-04 20:26:45 --> Query error: Duplicate entry '3449' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3449', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-04')
ERROR - 2020-01-04 20:26:45 --> Query error: Duplicate entry '3449' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3449', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-04')
ERROR - 2020-01-04 20:26:45 --> Query error: Duplicate entry '3449' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3449', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-04')
ERROR - 2020-01-04 20:26:45 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:26:45 --> Severity: Notice --> Use of undefined constant errUpload - assumed 'errUpload' C:\danxampp\htdocs\demo\application\modules\importdb\views\importdb.php 51
ERROR - 2020-01-04 20:26:45 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:26:45 --> 404 Page Not Found: /index
ERROR - 2020-01-04 20:28:21 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:28:22 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:28:22 --> 404 Page Not Found: /index
ERROR - 2020-01-04 20:28:27 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:28:27 --> Query error: Duplicate entry '3449' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3449', '3449', '3449', '3449', 1, '2020-01-04')
ERROR - 2020-01-04 20:28:27 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('BBCY TVET', 'BBCY TVET', 'BBCY TVET', 'BBCY TVET', 1, '2020-01-04')
ERROR - 2020-01-04 20:28:27 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('Addis Ababa', 'Addis Ababa', 'Addis Ababa', 'Addis Ababa', 1, '2020-01-04')
ERROR - 2020-01-04 20:28:27 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('Private', 'Private', 'Private', 'Private', 1, '2020-01-04')
ERROR - 2020-01-04 20:28:27 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:28:27 --> Severity: Notice --> Use of undefined constant errUpload - assumed 'errUpload' C:\danxampp\htdocs\demo\application\modules\importdb\views\importdb.php 51
ERROR - 2020-01-04 20:28:27 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:28:27 --> 404 Page Not Found: /index
ERROR - 2020-01-04 20:28:42 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:28:42 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:28:42 --> 404 Page Not Found: /index
ERROR - 2020-01-04 20:29:57 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:29:57 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:29:57 --> 404 Page Not Found: /index
ERROR - 2020-01-04 20:30:02 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:30:02 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 182
ERROR - 2020-01-04 20:30:02 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:30:02 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:30:02 --> 404 Page Not Found: /index
ERROR - 2020-01-04 20:30:18 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:30:18 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:30:18 --> 404 Page Not Found: /index
ERROR - 2020-01-04 20:30:22 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:31:01 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:31:23 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:31:32 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:31:34 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:31:34 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:31:34 --> 404 Page Not Found: /index
ERROR - 2020-01-04 20:32:03 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:32:03 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:32:03 --> 404 Page Not Found: /index
ERROR - 2020-01-04 20:32:08 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:32:32 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:35:02 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:35:03 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:35:03 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:35:03 --> 404 Page Not Found: /index
ERROR - 2020-01-04 20:35:07 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:35:08 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 167
ERROR - 2020-01-04 20:35:08 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:35:08 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:35:08 --> 404 Page Not Found: /index
ERROR - 2020-01-04 20:35:19 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:35:19 --> Query error: Duplicate entry '3448' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3448', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-04')
ERROR - 2020-01-04 20:35:19 --> Query error: Duplicate entry '3450' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3450', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-04')
ERROR - 2020-01-04 20:35:19 --> Query error: Duplicate entry '3451' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3451', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-04')
ERROR - 2020-01-04 20:35:19 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:35:19 --> Severity: Notice --> Use of undefined constant errUpload - assumed 'errUpload' C:\danxampp\htdocs\demo\application\modules\importdb\views\importdb.php 51
ERROR - 2020-01-04 20:35:20 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:35:20 --> 404 Page Not Found: /index
ERROR - 2020-01-04 20:35:43 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:35:43 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:35:44 --> 404 Page Not Found: /index
ERROR - 2020-01-04 20:35:48 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:35:48 --> Query error: Duplicate entry '3448' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3448', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-04')
ERROR - 2020-01-04 20:35:48 --> Query error: Duplicate entry '3450' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3450', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-04')
ERROR - 2020-01-04 20:35:48 --> Query error: Duplicate entry '3451' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3451', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-04')
ERROR - 2020-01-04 20:35:48 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:35:48 --> Severity: Notice --> Use of undefined constant errUpload - assumed 'errUpload' C:\danxampp\htdocs\demo\application\modules\importdb\views\importdb.php 51
ERROR - 2020-01-04 20:35:48 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:35:48 --> 404 Page Not Found: /index
ERROR - 2020-01-04 20:39:13 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:39:13 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:39:13 --> 404 Page Not Found: /index
ERROR - 2020-01-04 20:39:16 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:39:17 --> Query error: Duplicate entry '3448' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3448', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-04')
ERROR - 2020-01-04 20:39:17 --> Query error: Duplicate entry '3450' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3450', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-04')
ERROR - 2020-01-04 20:39:17 --> Query error: Duplicate entry '3451' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3451', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-04')
ERROR - 2020-01-04 20:39:17 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:39:17 --> Severity: Notice --> Use of undefined constant errUpload - assumed 'errUpload' C:\danxampp\htdocs\demo\application\modules\importdb\views\importdb.php 51
ERROR - 2020-01-04 20:39:17 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:39:17 --> 404 Page Not Found: /index
ERROR - 2020-01-04 20:40:30 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:40:30 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:40:30 --> 404 Page Not Found: /index
ERROR - 2020-01-04 20:40:35 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:40:35 --> Query error: Duplicate entry '3448' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3448', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-04')
ERROR - 2020-01-04 20:40:35 --> Query error: Duplicate entry '3450' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3450', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-04')
ERROR - 2020-01-04 20:40:36 --> Query error: Duplicate entry '3451' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3451', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-04')
ERROR - 2020-01-04 20:41:48 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:41:48 --> Query error: Duplicate entry '3448' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3448', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-04')
ERROR - 2020-01-04 20:41:48 --> Query error: Duplicate entry '3450' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3450', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-04')
ERROR - 2020-01-04 20:41:48 --> Query error: Duplicate entry '3451' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3451', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-04')
ERROR - 2020-01-04 20:41:48 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:41:48 --> Severity: Notice --> Use of undefined constant errUpload - assumed 'errUpload' C:\danxampp\htdocs\demo\application\modules\importdb\views\importdb.php 51
ERROR - 2020-01-04 20:41:49 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:41:49 --> 404 Page Not Found: /index
ERROR - 2020-01-04 20:42:13 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:42:13 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:42:13 --> 404 Page Not Found: /index
ERROR - 2020-01-04 20:42:19 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:42:19 --> Query error: Duplicate entry '3448' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3448', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-04')
ERROR - 2020-01-04 20:42:19 --> Query error: Duplicate entry '3450' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3450', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-04')
ERROR - 2020-01-04 20:42:19 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:42:19 --> Severity: Notice --> Use of undefined constant errUpload - assumed 'errUpload' C:\danxampp\htdocs\demo\application\modules\importdb\views\importdb.php 51
ERROR - 2020-01-04 20:42:19 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:42:19 --> 404 Page Not Found: /index
ERROR - 2020-01-04 20:42:54 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:42:54 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:42:54 --> 404 Page Not Found: /index
ERROR - 2020-01-04 20:42:59 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:42:59 --> Query error: Duplicate entry '3448' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3448', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-04')
ERROR - 2020-01-04 20:42:59 --> Query error: Duplicate entry '3450' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3450', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-04')
ERROR - 2020-01-04 20:42:59 --> Query error: Duplicate entry '3451' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3451', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-04')
ERROR - 2020-01-04 20:42:59 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:42:59 --> Severity: Notice --> Use of undefined constant errUpload - assumed 'errUpload' C:\danxampp\htdocs\demo\application\modules\importdb\views\importdb.php 51
ERROR - 2020-01-04 20:42:59 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:42:59 --> 404 Page Not Found: /index
ERROR - 2020-01-04 20:43:11 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:43:11 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:43:11 --> 404 Page Not Found: /index
ERROR - 2020-01-04 20:43:15 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:43:16 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 165
ERROR - 2020-01-04 20:43:16 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:43:16 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:43:16 --> 404 Page Not Found: /index
ERROR - 2020-01-04 20:44:54 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:44:55 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:44:55 --> 404 Page Not Found: /index
ERROR - 2020-01-04 20:44:59 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:44:59 --> Severity: Notice --> Array to string conversion C:\danxampp\htdocs\demo\system\database\DB_driver.php 1477
ERROR - 2020-01-04 20:44:59 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '0) VALUES (Array)' at line 1 - Invalid query: INSERT INTO `import_tvet` (0) VALUES (Array)
ERROR - 2020-01-04 20:44:59 --> Severity: Notice --> Array to string conversion C:\danxampp\htdocs\demo\system\database\DB_driver.php 1477
ERROR - 2020-01-04 20:44:59 --> Severity: Notice --> Array to string conversion C:\danxampp\htdocs\demo\system\database\DB_driver.php 1477
ERROR - 2020-01-04 20:44:59 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '0, 1) VALUES (Array, Array)' at line 1 - Invalid query: INSERT INTO `import_tvet` (0, 1) VALUES (Array, Array)
ERROR - 2020-01-04 20:44:59 --> Severity: Notice --> Array to string conversion C:\danxampp\htdocs\demo\system\database\DB_driver.php 1477
ERROR - 2020-01-04 20:44:59 --> Severity: Notice --> Array to string conversion C:\danxampp\htdocs\demo\system\database\DB_driver.php 1477
ERROR - 2020-01-04 20:44:59 --> Severity: Notice --> Array to string conversion C:\danxampp\htdocs\demo\system\database\DB_driver.php 1477
ERROR - 2020-01-04 20:44:59 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '0, 1, 2) VALUES (Array, Array, Array)' at line 1 - Invalid query: INSERT INTO `import_tvet` (0, 1, 2) VALUES (Array, Array, Array)
ERROR - 2020-01-04 20:44:59 --> Severity: Notice --> Array to string conversion C:\danxampp\htdocs\demo\system\database\DB_driver.php 1477
ERROR - 2020-01-04 20:44:59 --> Severity: Notice --> Array to string conversion C:\danxampp\htdocs\demo\system\database\DB_driver.php 1477
ERROR - 2020-01-04 20:44:59 --> Severity: Notice --> Array to string conversion C:\danxampp\htdocs\demo\system\database\DB_driver.php 1477
ERROR - 2020-01-04 20:44:59 --> Severity: Notice --> Array to string conversion C:\danxampp\htdocs\demo\system\database\DB_driver.php 1477
ERROR - 2020-01-04 20:44:59 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '0, 1, 2, 3) VALUES (Array, Array, Array, Array)' at line 1 - Invalid query: INSERT INTO `import_tvet` (0, 1, 2, 3) VALUES (Array, Array, Array, Array)
ERROR - 2020-01-04 20:44:59 --> Severity: Notice --> Array to string conversion C:\danxampp\htdocs\demo\system\database\DB_driver.php 1477
ERROR - 2020-01-04 20:44:59 --> Severity: Notice --> Array to string conversion C:\danxampp\htdocs\demo\system\database\DB_driver.php 1477
ERROR - 2020-01-04 20:44:59 --> Severity: Notice --> Array to string conversion C:\danxampp\htdocs\demo\system\database\DB_driver.php 1477
ERROR - 2020-01-04 20:44:59 --> Severity: Notice --> Array to string conversion C:\danxampp\htdocs\demo\system\database\DB_driver.php 1477
ERROR - 2020-01-04 20:44:59 --> Severity: Notice --> Array to string conversion C:\danxampp\htdocs\demo\system\database\DB_driver.php 1477
ERROR - 2020-01-04 20:44:59 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '0, 1, 2, 3, 4) VALUES (Array, Array, Array, Array, Array)' at line 1 - Invalid query: INSERT INTO `import_tvet` (0, 1, 2, 3, 4) VALUES (Array, Array, Array, Array, Array)
ERROR - 2020-01-04 20:44:59 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:44:59 --> Severity: Notice --> Use of undefined constant errUpload - assumed 'errUpload' C:\danxampp\htdocs\demo\application\modules\importdb\views\importdb.php 51
ERROR - 2020-01-04 20:44:59 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:44:59 --> 404 Page Not Found: /index
ERROR - 2020-01-04 20:45:12 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:45:12 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:45:12 --> 404 Page Not Found: /index
ERROR - 2020-01-04 20:45:16 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:45:16 --> Query error: Duplicate entry '3448' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3448', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-04')
ERROR - 2020-01-04 20:45:16 --> Query error: Duplicate entry '3450' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3450', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-04')
ERROR - 2020-01-04 20:45:16 --> Query error: Duplicate entry '3451' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3451', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-04')
ERROR - 2020-01-04 20:45:16 --> Query error: Duplicate entry '3452' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3452', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-04')
ERROR - 2020-01-04 20:45:16 --> Query error: Duplicate entry '3453' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3453', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-04')
ERROR - 2020-01-04 20:45:16 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:45:16 --> Severity: Notice --> Use of undefined constant errUpload - assumed 'errUpload' C:\danxampp\htdocs\demo\application\modules\importdb\views\importdb.php 51
ERROR - 2020-01-04 20:45:16 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:45:17 --> 404 Page Not Found: /index
ERROR - 2020-01-04 20:45:25 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:45:25 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:45:25 --> 404 Page Not Found: /index
ERROR - 2020-01-04 20:45:59 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:45:59 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:46:00 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:46:00 --> 404 Page Not Found: /index
ERROR - 2020-01-04 20:46:05 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:46:05 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:46:05 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:46:05 --> 404 Page Not Found: /index
ERROR - 2020-01-04 20:46:18 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:46:18 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:46:18 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:46:18 --> 404 Page Not Found: /index
ERROR - 2020-01-04 20:46:32 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:46:33 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:46:33 --> 404 Page Not Found: /index
ERROR - 2020-01-04 20:52:40 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:52:40 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:52:40 --> 404 Page Not Found: /index
ERROR - 2020-01-04 20:52:48 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:52:48 --> Query error: Duplicate entry '3448' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3448', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-04')
ERROR - 2020-01-04 20:52:48 --> Query error: Duplicate entry '3450' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3450', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-04')
ERROR - 2020-01-04 20:52:48 --> Query error: Duplicate entry '3451' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3451', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-04')
ERROR - 2020-01-04 20:52:48 --> Query error: Duplicate entry '3452' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3452', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-04')
ERROR - 2020-01-04 20:52:48 --> Query error: Duplicate entry '3453' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3453', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-04')
ERROR - 2020-01-04 20:52:48 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:52:48 --> Severity: Notice --> Use of undefined constant errUpload - assumed 'errUpload' C:\danxampp\htdocs\demo\application\modules\importdb\views\importdb.php 51
ERROR - 2020-01-04 20:52:48 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:52:48 --> 404 Page Not Found: /index
ERROR - 2020-01-04 20:54:47 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:54:47 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:54:47 --> 404 Page Not Found: /index
ERROR - 2020-01-04 20:54:54 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:54:54 --> Query error: Duplicate entry '3448' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3448', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-04')
ERROR - 2020-01-04 20:54:54 --> Query error: Duplicate entry '3450' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3450', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-04')
ERROR - 2020-01-04 20:54:54 --> Query error: Duplicate entry '3451' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3451', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-04')
ERROR - 2020-01-04 20:54:54 --> Query error: Duplicate entry '3452' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3452', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-04')
ERROR - 2020-01-04 20:54:54 --> Query error: Duplicate entry '3453' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('3453', 'BBCY TVET', 'Addis Ababa', 'Private', 1, '2020-01-04')
ERROR - 2020-01-04 20:54:54 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:54:54 --> Severity: Notice --> Use of undefined constant errUpload - assumed 'errUpload' C:\danxampp\htdocs\demo\application\modules\importdb\views\importdb.php 51
ERROR - 2020-01-04 20:54:54 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-04 20:54:54 --> 404 Page Not Found: /index
