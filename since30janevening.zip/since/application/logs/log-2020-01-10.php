<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-10 11:27:23 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-10 11:27:23 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-10 11:27:28 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-10 11:27:28 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-10 11:27:34 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-10 11:27:34 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-10 11:27:34 --> 404 Page Not Found: /index
ERROR - 2020-01-10 11:27:41 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-10 11:27:41 --> Query error: Duplicate entry '931743255-2019-04-01' for key 'PRIMARY' - Invalid query: INSERT INTO `import_beneficiaries` (`beneficiary_id`, `sex`, `region`, `entry_date_to_since`, `target_group`, `value_chain`, `entry_point_income`, `endline_income`, `type_of_income`, `disabled`, `Employed`, `consortium`, `status`, `postdate`) VALUES ('931743255', 'Female', 'Addis Ababa', '2019-04-01', 'Returnee', '3', '', '', 'Informal', 'FALSE', 'FALSE', 'Lot_1_VIS_2nd_batch', 1, '2020-01-10')
ERROR - 2020-01-10 11:27:41 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-10 11:27:41 --> Severity: Notice --> Use of undefined constant errUpload - assumed 'errUpload' C:\danxampp\htdocs\demo\application\modules\importdb\views\importdb.php 123
ERROR - 2020-01-10 11:27:41 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-10 11:27:41 --> 404 Page Not Found: /index
ERROR - 2020-01-10 11:28:46 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-10 11:28:46 --> Severity: Notice --> Undefined variable: Errmessage C:\danxampp\htdocs\demo\application\modules\importdb\controllers\Importdb.php 584
ERROR - 2020-01-10 11:28:46 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-10 11:28:46 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-10 11:28:46 --> 404 Page Not Found: /index
ERROR - 2020-01-10 11:29:35 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-10 11:29:35 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-10 11:29:35 --> 404 Page Not Found: /index
ERROR - 2020-01-10 11:31:58 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-10 11:31:58 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-10 11:31:58 --> 404 Page Not Found: /index
ERROR - 2020-01-10 11:32:09 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-10 11:32:09 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-10 11:32:09 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-10 11:32:09 --> 404 Page Not Found: /index
ERROR - 2020-01-10 11:48:17 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-10 11:48:18 --> Query error: Duplicate entry '100000-Addis Ababa' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100000', 'General Wingate College11', 'Addis Ababa', 'Public', 1, '2020-01-10')
ERROR - 2020-01-10 11:48:18 --> Query error: Duplicate entry '100001-Addis Ababa' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100001', 'Lideta Manufacturing College', 'Addis Ababa', 'Public', 1, '2020-01-10')
ERROR - 2020-01-10 11:48:18 --> Query error: Duplicate entry '100002-Addis Ababa' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100002', 'Misrak Polytechnic College', 'Addis Ababa', 'Public', 1, '2020-01-10')
ERROR - 2020-01-10 11:48:18 --> Query error: Duplicate entry '100005-Addis Ababa' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100005', 'Yeka Industrial College', 'Addis Ababa', 'Public', 1, '2020-01-10')
ERROR - 2020-01-10 11:48:18 --> Query error: Duplicate entry '100008-Addis Ababa' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100008', 'Entoto PTC', 'Addis Ababa', 'Public', 1, '2020-01-10')
ERROR - 2020-01-10 11:48:18 --> Query error: Duplicate entry '100009-Addis Ababa' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100009', 'Addis Ketema Manufacturing College', 'Addis Ababa', 'Public', 1, '2020-01-10')
ERROR - 2020-01-10 11:48:18 --> Query error: Duplicate entry '100010-Addis Ababa' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100010', 'General Wingate College', 'Addis Ababa', '', 1, '2020-01-10')
ERROR - 2020-01-10 11:48:18 --> Query error: Duplicate entry '100011-Addis Ababa' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100011', 'General Wingate College4545', 'Addis Ababa', 'Public', 1, '2020-01-10')
ERROR - 2020-01-10 11:48:18 --> Query error: Duplicate entry '100012-Addis Ababa' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100012', 'Entoto PTC1', 'Addis Ababa', 'Public', 1, '2020-01-10')
ERROR - 2020-01-10 11:48:18 --> Query error: Duplicate entry '100014-Addis Ababa' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100014', 'Entoto PTC222', 'Addis Ababa', 'Public', 1, '2020-01-10')
ERROR - 2020-01-10 11:48:18 --> Query error: Duplicate entry '100017-Addis Ababa' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100017', 'Entoto_PTC', 'Addis Ababa', 'Public', 1, '2020-01-10')
ERROR - 2020-01-10 11:48:18 --> Query error: Duplicate entry '100018-Addis Ababa' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100018', 'Entoto_PTC2', 'Addis Ababa', 'Public', 1, '2020-01-10')
ERROR - 2020-01-10 11:48:18 --> Query error: Duplicate entry '100019-Addis Ababa' for key 'PRIMARY' - Invalid query: INSERT INTO `import_tvet` (`tvet_id`, `tvet_name`, `region`, `tvet_type`, `status`, `postdate`) VALUES ('100019', 'Entoto PTC22222', 'Addis Ababa', 'Public', 1, '2020-01-10')
ERROR - 2020-01-10 11:48:18 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-10 11:48:18 --> Severity: Notice --> Use of undefined constant errUpload - assumed 'errUpload' C:\danxampp\htdocs\demo\application\modules\importdb\views\importdb.php 123
ERROR - 2020-01-10 11:48:18 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-10 11:48:18 --> 404 Page Not Found: /index
ERROR - 2020-01-10 11:48:26 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-10 11:48:26 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-10 11:48:26 --> 404 Page Not Found: /index
ERROR - 2020-01-10 11:48:29 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-10 11:59:29 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-10 14:25:44 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-10 14:25:44 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-10 14:25:53 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-10 14:25:54 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-10 14:25:56 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
ERROR - 2020-01-10 14:26:03 --> $config['composer_autoload'] is set to TRUE but C:\danxampp\htdocs\demo\application\vendor/autoload.php was not found.
